﻿namespace HotelSolicitacoesAPI.DTO
{
    public class HospedeLoginDTO
    {
        public int NumeroApartamento { get; set; }
        public string Sobrenome { get; set; } = string.Empty;
    }
}
