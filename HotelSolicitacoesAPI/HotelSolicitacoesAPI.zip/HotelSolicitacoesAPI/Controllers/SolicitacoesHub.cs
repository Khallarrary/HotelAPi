﻿using Microsoft.AspNetCore.SignalR;

namespace HotelSolicitacoesAPI.Controllers

{
    public class SolicitacoesHub : Hub
    {
    }
}
